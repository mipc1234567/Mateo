USE `supermercado`;

update producto set Animal_Producto='Res'
where Animal_Producto='cerdo';

update producto set Nombre_Producto='Pernil'
where Nombre_Producto='Pierna';
update inventario  set Producto_Inventario='Pernil'
where producto_inventario='Pierna'; 


DELETE FROM  inventario_producto
WHERE Producto_fk=10
ORDER BY Producto_fk
LIMIT 1
;
DELETE FROM  inventario
WHERE Id_Inventario=10
ORDER BY Id_Inventario
LIMIT 1
;
DELETE FROM producto
WHERE Id_Producto=10
ORDER BY Nombre_Producto
LIMIT 1
;

/*SELECT 
inventario.*
FROM inventario INNER JOIN  producto_carnico
ON (producto_inventario=producto_carnico);
update inventario  
set producto_inventario='Pernil'
from inventario inner join producto_carnico
ON (producto_inventario=Nombre_Producto)
where producto_inventario='Pierna';
*/