CREATE SCHEMA IF NOT EXISTS `supermercado` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `supermercado`;
drop table responsable;
drop table inventario;
drop table producto;
drop table inventario_producto;

-- -----------------------------------------------------
-- Table `supermercado`.`fruta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `supermercado`.`producto` (
  `Id_Producto` INT NOT NULL,
  `Color_Producto` VARCHAR(100)  NULL,
  `Cantidad_Producto` INT NULL,
  `Nombre_Producto` VARCHAR(100) NOT NULL,
  `Animal_Producto` VARCHAR(100)  NULL,
  `TienePelo_Producto` BOOLEAN NULL,
  PRIMARY KEY (`Id_producto`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

-- -----------------------------------------------------
-- Table `supermercado`.`responsable`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `supermercado`.`responsable` (
  `Id_Responsable` INT NOT NULL,
  `Username_Responsable` VARCHAR(50) NOT NULL,
  `Nombre_Responsable` VARCHAR(50) NOT NULL,
  `Funcion_Responsable`VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Username_Responsable`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;
-- -----------------------------------------------------
-- Table `supermercado`.`inventario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `supermercado`.`inventario` (
`Id_Inventario` INT NOT NULL,
  `Nombre_Inventario` VARCHAR(50) NOT NULL,
  `Username_Responsable_fk` VARCHAR(25) NOT NULL,
   `Producto_Inventario` VARCHAR(25) NOT NULL,
   FOREIGN KEY(Username_Responsable_fk) REFERENCES responsable(Username_Responsable),
  PRIMARY KEY (`Id_Inventario`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `supermercado`.`inventario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `supermercado`.`inventario_producto` (
`Id_producto_inventario` INT not NULL,
`Producto_fk` INT NOT NULL,
`Inventario_fk` INT NOT NULL,
`Fecha_inventario` DATE,
FOREIGN KEY(Producto_fk) REFERENCES producto(Id_Producto),
FOREIGN KEY(Inventario_fk) REFERENCES inventario(Id_Inventario),
PRIMARY KEY (`Id_producto_inventario`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;