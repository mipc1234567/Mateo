USE `supermercado`;

insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(1,'Morado',1, 'Agraz', null,null);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(2,'Amarillo',3, 'Durazno', null,null);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(3,null,10, 'Filete','Cerdo',true);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(4,'Verde',3, 'Freijoa', null,null);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(5,'Morado',9, 'Mora', null,null);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(6,'Rojo',12, 'Fresa', null,null);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(8,null,1000, 'Palmito','Cangrejo',false);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(7,'verde',2, 'Pera', null,null);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(9,null,25, 'Pierna','pollo',false);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(10,null,100, 'Tenaza','Cangrejo',false);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(11,null,100, 'Hígado','Res',true);
insert into producto(Id_Producto,Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto) values(12,null,100, 'Hígado','Res',true);

insert into responsable(Id_Responsable,Username_Responsable,Nombre_Responsable,Funcion_Responsable)values( 1,'jvalde', 'Juan Valdez','frutas viceras');
insert into responsable(Id_Responsable,Username_Responsable,Nombre_Responsable,Funcion_Responsable)values( 2,'opere', 'Oscar Perez','carnes' );
insert into responsable(Id_Responsable,Username_Responsable,Nombre_Responsable,Funcion_Responsable)values( 3,'croja','Carolina Rojas','otros'); 

insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(8,'otros','croja','Palmito');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(10,'otros','croja','Tenaza');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(3,'carnes','opere','Filete');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(4,'frutas viceras','jvalde','Freijoa');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(5,'frutas viceras','jvalde','Mora');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(6,'frutas viceras','jvalde','Fresa');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(7,'frutas viceras','jvalde','Pera');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(1,'frutas viceras','jvalde','Agraz');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(11,'frutas viceras','jvalde','Hígado');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(12,'frutas viceras','croja','Hígado');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(9,'otros','croja','Pierna');
insert into inventario(Id_Inventario,Nombre_Inventario,Username_Responsable_fk,Producto_Inventario)values(2,'frutas viceras','jvalde','Durazno');

insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(1,1,1,'2010/12/19');/*AGRAZ*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(8,8,8,'2010/02/15');/*Palmito*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(10,10,10,'2010/02/15');/*Tenaza*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(3,3,3,'2010/12/15'); /*Filete*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(4,4,4,'2010/12/15');/*Feijoa*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(5,5,5,'2010/12/15');/*Mora*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(6,6,6,'2010/12/15');/*Fresa*/ 
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(7,7,7,'2010/12/13');/*Pera*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(11,11,11,'2011/12/15');/*Hígado*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(12,12,12,'2013/01/14');/*Hígado*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(9,9,9,'2015/12/15');/*Pierna*/
insert into inventario_producto(Id_producto_inventario,Producto_fk,Inventario_fk,Fecha_inventario)values(2,2,2,'2010/12/19');/*DURAZNO*/
select *from producto

