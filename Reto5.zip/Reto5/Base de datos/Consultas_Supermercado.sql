USE `supermercado`;

Select 'Consulta 1';
SELECT  producto.Nombre_Producto, inventario_producto.Fecha_inventario
FROM (inventario_producto JOIN producto ON inventario_producto.Producto_fk=producto.Id_Producto)
ORDER BY inventario_producto.Fecha_inventario desc;

/*SELECT inventario_producto.Fecha_inventario, producto.Nombre_Producto
FROM inventario_producto,producto
WHERE inventario_producto.Producto_fk=producto.Id_Producto
order by inventario_producto.Fecha_inventario, producto.Nombre_Producto;
*/

Select 'Consulta 2';
SELECT  Nombre_Producto
FROM (inventario_producto JOIN producto ON inventario_producto.Producto_fk=producto.Id_Producto)
where Fecha_inventario >="2011/12/15"
ORDER BY producto.Nombre_Producto;

/*Select Fecha_inventario, MIN(CAST(Fecha_inventario AS CHAR))
from inventario_producto
where Fecha_inventario>2011/12/15
group by Fecha_inventario
;*/

Select 'Consulta 3';
Select Nombre_Responsable
FROM (inventario JOIN responsable ON inventario.Username_Responsable_fk=responsable.Username_Responsable)
where Producto_Inventario='Higado'
order by Nombre_Responsable;


Select 'Consulta 4';
Select Nombre_Responsable,COUNT(Username_Responsable)
FROM (responsable JOIN inventario ON responsable.Username_Responsable=inventario.Username_Responsable_fk)
group by Nombre_Responsable;

Select 'Consulta 5';
SELECT SUM(producto.Cantidad_Producto)
FROM  inventario_producto
LEFT JOIN  inventario ON inventario_producto.Id_producto_inventario =inventario.Id_Inventario  
LEFT JOIN producto ON inventario_producto.Inventario_fk = producto.Id_Producto 
WHERE inventario.Username_Responsable_fk = 'croja' or  inventario.Username_Responsable_fk = 'opere'
ORDER BY inventario_producto.Id_producto_inventario  ASC; 

/*Select 'Consulta 5';
SELECT SUM(producto.Cantidad_Producto), inventario_producto.Id_producto_inventario, inventario.Username_Responsable_fk
FROM  inventario_producto
LEFT JOIN  inventario ON inventario_producto.Id_producto_inventario =inventario.Id_Inventario  
LEFT JOIN producto ON inventario_producto.Inventario_fk = producto.Id_Producto 
WHERE inventario.Username_Responsable_fk = 'croja' or  inventario.Username_Responsable_fk = 'opere'
ORDER BY inventario_producto.Id_producto_inventario  ASC; */
