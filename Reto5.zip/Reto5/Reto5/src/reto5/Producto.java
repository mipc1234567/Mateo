/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reto5;

import java.io.PrintStream;
import java.util.ArrayList;

/**
 *
 * @author Mateo Ivan Peña
 */
public class Producto {
    
    
    /**
     *ATRIBUTOS 
    */
    
    public String Nombre;
    public long ID;
    public int Cantidad;
    public ArrayList<Producto> Productos=new ArrayList<Producto>();
    public String Animal_Producto;
    public boolean Tiene_pelo;
 
   /**
    * constructor del producto recibe los parametros de creacion de un producto
    * @param nombre
    * @param id
    * @param cantidad
    * @param animalproducto
    * @param tienepelo 
    */ 
 public Producto(String nombre,long id, int cantidad,String animalproducto,boolean tienepelo){
        this.ID=id;
        this.Nombre=nombre;
        this.Cantidad=cantidad;
        this.Animal_Producto=animalproducto;
        this.Tiene_pelo=tienepelo;
          
    }

    public Producto() {
    }
 
 public void AgregarProducto(Producto product){
     Productos.add(product);
 }
 
  public String ListarProducto(){    
       String resultado="";
   System.out.println("*Inventario de productos*"+"\t");
      for (Producto o : Productos) {
        resultado+="\t- Id: " + o.getID() + "\n\tCantidad: " + getCantidad() + " Kg" + "\n\tNombre: " + getNombre();
          }
  return resultado;

 }
  
  public String ListarProducto1(ArrayList<Producto> lista){    
       String resultado="";
      for (Producto o : lista) {
        resultado+="\t- Id: " + o.getID() + "\n\tCantidad: " + getCantidad() + " Kg" + "\n\tNombre: " + getNombre();
          }
  return resultado;

 }

   public void SalirPrograma(){
       System.exit(0);
    
 }
 
 /**
  *     GETTER AN SETTER
  */
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }
    
   
    
}
