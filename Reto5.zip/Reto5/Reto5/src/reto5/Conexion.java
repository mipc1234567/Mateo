/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reto5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;



/**
 * permite controlar la conexion a la base de datos
 * @author Mateo Ivan Peña
 */
public class Conexion {
    
private final String cadenaConexion = "jdbc:mysql://localhost:3306/supermercado";
private final String usuario = "root";
private final String password = "x46q8z11";
public int id_producto;
public String color_producto;
public int cantidad_producto;
public String nombre_producto;
public String animal_producto;
public Boolean tiene_pelo_producto;
public String[][] respuesta;
public int tamaño;

              
    
    public Conexion(){
      /**
       * leer datos a cargar
       */  
     LoadDates();
     /**
      * guardar los datos en una variable local para trabajarlos
      */
    initilize();
    
    }
    /**
     * permite cargar la cantidad de registros que tiene la base de datos enlazada
     * para poder crear un vector de string que almacene dichos datos 
     */
    public void LoadDates(){
        int cont=0;
        tamaño=0;
            try {
            Connection conn = DriverManager.getConnection(cadenaConexion, usuario, password);
            if(conn != null)
                System.out.println("esta cargando datos");
            /**
             * esta modificacion se hace dependiendo de los datos a insertar en la tabla
             */
                String sql = "SELECT *from producto";
               
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            
         while(result.next()){
             cont++;
         }
       } catch (SQLException ex) {
  JOptionPane.showMessageDialog(null, "codigo"+ ex.getErrorCode()+"\nerror"+ex.getMessage());
            ex.printStackTrace();
        }
            /**
             * aumenta el tamaño del tamaño del String respuesta [][] cada vez que se agrega un producto
             * para poderlo instanciar en el metodo "initializace" respuesta......
             */
    tamaño+=cont;
        System.out.println("la cantidad de elementos cargados es :"+ tamaño);
    }
    /**
     * permite cargar los datos de la base de datos creada a partir del tamaño definido 
     * en load dates 
     * @return 
     */
    public String [][] initilize(){
     String[][] respuesta=new String[tamaño][tamaño*2];
    int cont=0;
            try {
         
            
            Connection conn = DriverManager.getConnection(cadenaConexion, usuario, password);
            if(conn != null)
                System.out.println("Se ha conectado  la base de datos Inicializando");
            /**
             * esta cosulta selecciona todos los elementos de la lista
             */
             String sql = "SELECT *from producto";
            
            Statement statement = conn.createStatement();
            
            ResultSet result = statement.executeQuery(sql);
            
       while(result.next()){
   String cadenaAux="";
  int id_producto=result.getInt(1);
 String color_producto=result.getString(2);;
int cantidad_producto=result.getInt(3);;
String nombre_producto=result.getString(4);;
 String animal_producto=result.getString(5);;;
 Boolean tiene_pelo_producto=result.getBoolean(6);
 cadenaAux+=id_producto+" "+cantidad_producto+" "+color_producto+" "+nombre_producto+" "+ animal_producto+" "+tiene_pelo_producto.toString();
 String []valoresTemp= cadenaAux.split(" ");


                for (int i = 0; i <valoresTemp.length; i++) {
                respuesta[cont][i]=valoresTemp[i];
                    
                }
 
                System.out.println("identificador "+ id_producto+"color "+color_producto+
                        "cantidad "+cantidad_producto+"nombre "+nombre_producto+"animal "+animal_producto +"tiene pelo "+tiene_pelo_producto);
                 cont++;
            }
            
       } catch (SQLException ex) {
  JOptionPane.showMessageDialog(null, "codigo"+ ex.getErrorCode()+"\nerror"+ex.getMessage());
            ex.printStackTrace();
        }
    return respuesta;
           
    }
    
    public void Save_DataBase(int identificador, String color, int cantidad,String nombre,String animal, Boolean tienepelo ){
  this.id_producto=identificador;
 this.color_producto= color;
 this.cantidad_producto= cantidad;
  this.nombre_producto=nombre;
 this. animal_producto=animal;
 this. tiene_pelo_producto=tienepelo;

              try {
                   
            Connection conn = DriverManager.getConnection(cadenaConexion, usuario, password);
            if(conn != null)
                System.out.println("Se ha conectado  la base de datos");
            /**
             * esta modificacion se hace dependiendo de los datos a insertar en la tabla
             */
            String sql="INSERT INTO producto  (Id_Producto, Color_Producto,Cantidad_Producto,Nombre_Producto,Animal_Producto,TienePelo_Producto)"
                    + "VALUES(?,?,?,?,?,?)";
           PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1,id_producto);
            statement.setString(2, color_producto);
            statement.setInt(3, cantidad_producto);
            statement.setString(4,nombre_producto);
               statement.setString(5,animal_producto);
               statement.setBoolean(6, tiene_pelo_producto);
                tamaño+=1;
            
            int rows = statement.executeUpdate();
          
            
             if(rows > 0)
                 System.out.println("Inserto " + rows + " filas");
       } catch (SQLException ex) {
  JOptionPane.showMessageDialog(null, "codigo"+ ex.getErrorCode()+"\nerror"+ex.getMessage());
            ex.printStackTrace();
        }

    }
    /**
     * permite borrar de la base de datos el producto con el id especificado como parametro
     * 
     * @param identificador 
     */
     public void Delete_DataBase(int identificador){
     this.id_producto=identificador;
            try {
            Connection conn = DriverManager.getConnection(cadenaConexion, usuario, password);
            if(conn != null)
                System.out.println("Se ha conectado  la base de datos para borrar");
             String sql2 = "DELETE FROM inventario_producto WHERE Producto_fk=?";
             String sql1 = "DELETE FROM inventario WHERE Id_Inventario=?";
             String sql = "DELETE FROM producto WHERE Id_Producto=?";
                     
            
            PreparedStatement statement2 = conn.prepareStatement(sql2);
            statement2.setInt(1,id_producto);
          
            PreparedStatement statement1 = conn.prepareStatement(sql1);
            statement1.setInt(1,id_producto);
               
            
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1,id_producto);
          
            
                System.out.println(id_producto);
             int producto_eliminado2=statement2.executeUpdate();
            int producto_eliminado1=statement1.executeUpdate();
            int producto_eliminado=statement.executeUpdate();
                System.out.println("este valor eliminado es "+producto_eliminado2);
                System.out.println("este valor eliminado es "+producto_eliminado1);
                System.out.println("este valor eliminado es "+producto_eliminado);
            if(producto_eliminado>0){
                System.out.println("borrado exitoso");
            }        

       } catch (SQLException ex) {
           
                JOptionPane.showMessageDialog(null, "codigo"+ ex.getErrorCode()+"\nerror"+ex.getMessage());
 
            ex.printStackTrace();
        }  
}
     /**
      * permite actualizar de la base de datos el producto que se pasa por parametro 
      * @param identificador
      * @param color
      * @param cantidad
      * @param nombre
      * @param animal
      * @param tienepelo 
      */
     public void UpdateProductos(int identificador, String color, int cantidad,String nombre,String animal, Boolean tienepelo ){
  this.id_producto=identificador;
 this.color_producto= color;
 this.cantidad_producto= cantidad;
  this.nombre_producto=nombre;
 this. animal_producto=animal;
 this. tiene_pelo_producto=tienepelo;

              try {
                   
            Connection conn = DriverManager.getConnection(cadenaConexion, usuario, password);
            if(conn != null)
                System.out.println("Se ha conectado  la base de datos");
            /**
             * esta modificacion se hace dependiendo de los datos a insertar en la tabla
             */
            String sql=" UPDATE producto SET Color_Producto=?,Cantidad_Producto=?, Nombre_Producto=? ,Animal_Producto=?,TienePelo_Producto=? "
                    + "WHERE Id_Producto=?";
           PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, color_producto);
            statement.setInt(2,cantidad_producto);
            statement.setString(3,nombre_producto);
            statement.setString(4,animal_producto);
            statement.setBoolean(5,tiene_pelo_producto);
            statement.setInt(6,id_producto);

            int rows = statement.executeUpdate();
             if(rows > 0)
                 System.out.println("Actualizo " + rows + " filas");
       } catch (SQLException ex) {
  JOptionPane.showMessageDialog(null, "codigo"+ ex.getErrorCode()+"\nerror"+ex.getMessage());
            ex.printStackTrace();
        }
     }
     /**
      * permite buscar productos de la base de datos a partir del id del producto ,entrega un vector de string con los 
      * componetes especificos del producto 
      * @param id
      * @return 
      */
     public String[][] SearchProductos(int id){
         System.out.println(id);
         this.id_producto=id;
          int idp=0;
         try {
                   
            Connection conn = DriverManager.getConnection(cadenaConexion, usuario, password);
            if(conn != null)
                System.out.println("Se ha conectado  la base de datos");
            
                String sql = "SELECT *from producto";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);
            
while(result.next()){
String cadenaAux="";
int id_producto=result.getInt(1);
String color_producto=result.getString(2);
int cantidad_producto=result.getInt(3);
String nombre_producto=result.getString(4);
String animal_producto=result.getString(5);
Boolean tiene_pelo_producto=result.getBoolean(6);
cadenaAux+=id_producto+" "+cantidad_producto+" "+color_producto+" "+nombre_producto+" "+ animal_producto+" "+tiene_pelo_producto.toString();

  System.out.println("identificador "+ id_producto+"color "+color_producto+
                        "cantidad "+cantidad_producto+"nombre "+nombre_producto+"animal "+animal_producto +"tiene pelo "+tiene_pelo_producto);
                   
 if(id_producto==this.id_producto){
     System.out.println("paso y encontro el id");
    
 String []valoresTemp= cadenaAux.split(" ");
 respuesta=new String[1][valoresTemp.length];
     System.out.println(" " +valoresTemp.length);
for (int i = 0; i <valoresTemp.length-1; i++) {
    System.out.println(valoresTemp[idp+1]);
respuesta[idp][i]=valoresTemp[i];
    } 
  }else{
}
    }} catch (SQLException ex) {
  JOptionPane.showMessageDialog(null, "codigo"+ ex.getErrorCode()+"\nerror"+ex.getMessage());
            ex.printStackTrace();
        }
    return respuesta;
}
     
        public int getTamaño() {
        return tamaño;
    }
}
